// This script should be added to all pages to handle the page mimicry/renaming
// Save this as mimicry.js in a js folder and include it on all pages

document.addEventListener('DOMContentLoaded', function() {
    // Check if there's a saved style and apply it
    const savedTitle = localStorage.getItem('pageMimicTitle');
    const savedIcon = localStorage.getItem('pageMimicIcon');
    
    // Apply saved title if available
    if (savedTitle) {
        document.title = savedTitle;
    }
    
    // Apply saved favicon if available
    if (savedIcon) {
        const favicon = document.querySelector('link[rel="icon"]');
        if (favicon) {
            favicon.href = savedIcon;
        }
    }
});